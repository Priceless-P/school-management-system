<?php

use classes\Admin\Admin;

require_once '../classes/Admin.php';
if($_SERVER["REQUEST_METHOD"]=="POST")
{

    $password = trim($_POST['password']);
    $new_pass = password_hash($password, PASSWORD_DEFAULT);
    $data = [
        'full-name'=>trim($_POST['full-name']),
        "username"=> trim($_POST['username']),
        "email"=> trim( $_POST['email']),
        'role'=> 'student',
        'password'=> $new_pass
    ];
    $login = new Admin();
    $login->setStudents($data);
}
